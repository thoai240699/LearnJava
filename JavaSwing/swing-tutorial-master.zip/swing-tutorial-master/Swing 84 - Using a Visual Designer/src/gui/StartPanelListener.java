package gui;

public interface StartPanelListener {
	public void startGame();
}

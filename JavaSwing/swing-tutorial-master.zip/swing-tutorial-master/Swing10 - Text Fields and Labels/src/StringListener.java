
public interface StringListener {
	public void textEmitted(String text);
}

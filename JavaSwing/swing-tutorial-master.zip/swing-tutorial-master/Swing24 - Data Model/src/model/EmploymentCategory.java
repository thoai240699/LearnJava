package model;

public enum EmploymentCategory {
	employed,
	selfEmployed,
	unemployed,
	other
}

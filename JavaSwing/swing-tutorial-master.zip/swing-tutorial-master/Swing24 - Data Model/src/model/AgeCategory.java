package model;

public enum AgeCategory {
	child,
	adult,
	senior
}

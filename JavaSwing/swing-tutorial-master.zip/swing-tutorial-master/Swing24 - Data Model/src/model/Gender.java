package model;

public enum Gender {
	male,
	female
}
